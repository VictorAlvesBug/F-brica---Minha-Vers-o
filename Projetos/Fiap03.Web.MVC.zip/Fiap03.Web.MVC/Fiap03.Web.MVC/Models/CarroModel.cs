﻿using Fiap03.MOD;
using Fiap03.MOD.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Fiap03.Web.MVC.Models
{
    public class CarroModel
    {
        public int Id { get; set; }
        //FK
        [Display(Name = "Marca *")]
        public int MarcaId { get; set; }
        [Display(Name = "Nome *")]
        public string Marca { get; set; }

        //? --> PERMITE QUE O COMBUSTIVEL SEJA NULL
        [Display(Name = "Combustível")]
        public Combustivel? Combustivel { get; set; }
        public int Ano { get; set; }
        public bool Esportivo { get; set; }
        [Display(Name = "Placa *")]
        public string Placa { get; set; }

        [Display(Name = "Descrição")]
        public string Descricao { get; set; }

        //FK
        public DocumentoModel Documento { get; set; }

        public int Renavam { get; set; }

        public CarroModel() { }

        public CarroModel(CarroMOD mod)
        {
            Id = mod.Id;
            MarcaId = mod.MarcaId;
            Marca = mod.Marca;
            Combustivel = mod.Combustivel;
            Ano = mod.Ano;
            Esportivo = mod.Esportivo;
            Placa = mod.Placa;
            Descricao = mod.Descricao;
            if (mod.Documento != null)
            {
                Documento = new DocumentoModel(mod.Documento);
            }
        }
    }
}