﻿using Fiap03.DAL.Repositories;
using Fiap03.DAL.Repositories.Interfaces;
using Fiap03.MOD;
using Fiap03.Web.MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Fiap03.Web.MVC.Controllers
{
    public class ModeloController : Controller
    {
        private IModeloRepository _modeloRepository = new ModeloRepository();
        private IMarcaRepository _marcaRepository = new MarcaRepository();
        private static int Id_da_Marca;

        public struct Modelo_1_e_N
        {
            public ModeloModel exemplo;
            public IList<ModeloModel> lista;
        }

        private ModeloMOD ModeloModel_To_ModeloMOD(ModeloModel model)
        {
            var mod = new ModeloMOD()
            {
                Id = model.Id,
                Nome = model.Nome,
                MarcaId = model.MarcaId
            };

            return mod;
        }

        [HttpGet]
        public ActionResult Index(int marcaId)
        {
            TempData["marca"] = _marcaRepository.Buscar(marcaId).Nome;
            Id_da_Marca = marcaId;
            var listaModeloModel = new List<ModeloModel>();
            var listaModeloMOD = _modeloRepository.Listar(marcaId);
            listaModeloMOD.ToList().ForEach(m => listaModeloModel.Add(new ModeloModel(m)));
            //ViewBag.Modelos = listaModeloModel;
            //ViewBag.Modelo = new ModeloModel();

            return View(listaModeloModel);

            /*Modelo_1_e_N um_e_varios = new Modelo_1_e_N();
            um_e_varios.exemplo = new ModeloModel();
            um_e_varios.lista = listaModeloModel;
            return View(um_e_varios);*/

            /*var modelo_listaModelo = new List<object>();
            modelo_listaModelo.Add(new ModeloModel());
            modelo_listaModelo.Add(listaModeloModel);
            return View(modelo_listaModelo);*/
        }

        [HttpPost]
        public ActionResult Cadastrar(string nome)
        {
            var model = new ModeloModel()
            {
                Nome = nome,
                MarcaId = Id_da_Marca
            };

            var mod = ModeloModel_To_ModeloMOD(model);
            _modeloRepository.Cadastrar(mod);
            return RedirectToAction("Listar", "Marca");
        }
    }
}