﻿using Fiap03.MOD;
using Fiap03.MOD.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fiap03.MOD
{
    public class CarroMOD
    {
        public int Id { get; set; }
        public int MarcaId { get; set; }
        public string Marca { get; set; }
        public string Placa { get; set; }
        public int Ano { get; set; }
        public bool Esportivo { get; set; }
        public Combustivel? Combustivel { get; set; }
        public string Descricao { get; set; }
        //FK
        public int Renavam { get; set; }
        public DocumentoMOD Documento { get; set; }

        /*public CarroMOD() { }

        public CarroMOD(CarroModel model)
        {
            Id = model.Id;
            MarcaId = model.MarcaId;
            Marca = model.Marca;
            Combustivel = model.Combustivel;
            Ano = model.Ano;
            Esportivo = model.Esportivo;
            Placa = model.Placa;
            Descricao = model.Descricao;
            Documento = new DocumentoMOD(model.Documento);
        }*/
    }
}