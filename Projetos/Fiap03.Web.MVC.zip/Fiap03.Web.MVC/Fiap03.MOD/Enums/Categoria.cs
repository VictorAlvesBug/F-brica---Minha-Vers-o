﻿namespace Fiap03.MOD.Enums
{
    public enum Categoria
    {
        Hatch, Sedan, Suv, Pickup
    }
}