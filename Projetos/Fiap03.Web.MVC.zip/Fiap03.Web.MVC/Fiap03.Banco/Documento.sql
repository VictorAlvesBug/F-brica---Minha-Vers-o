﻿CREATE TABLE [dbo].[Documento]
(
	[Renavam] INT NOT NULL PRIMARY KEY, 
    [Categoria] INT NOT NULL, 
    [DataFabricacao] DATE NOT NULL
)
